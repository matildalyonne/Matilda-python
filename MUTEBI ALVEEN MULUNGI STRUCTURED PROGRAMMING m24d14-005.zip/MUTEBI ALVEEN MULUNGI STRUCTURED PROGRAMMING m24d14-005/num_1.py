print("Welcome to the Temperature Conversion Tool! \nThis program allows you to convert temperatures between Celsius, Fahrenheit,")

def main():
    celsius = eval(input("What is the Celsius temperature? "))
    fahrenheit = 9/5 * celsius + 32
    print("The temperature is", fahrenheit, "degrees Fahrenheit.")
main()
 
 
 