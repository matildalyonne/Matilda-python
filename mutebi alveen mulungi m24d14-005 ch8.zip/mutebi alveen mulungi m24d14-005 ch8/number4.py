def syracuse_sequence(n):
    sequence = [n]
    while n != 1:
        if n % 2 == 0:
            n = n // 2
        else:
            n = 3 * n + 1
        sequence.append(n)
    return sequence
#get the starting value from the user
start_value = int(input("Enter a starting natural number: "))
sequence = syracuse_sequence(start_value)
print("syracuse sequence:", sequence)