def get_even_numbers(numbers):
    even_numbers = [num for num in numbers if num % 2 == 0]
    return even_numbers
input_list = [36, 37,92,893,23,35,3457,374,216,247]
result = get_even_numbers(input_list)
print("Even numbers:", result)