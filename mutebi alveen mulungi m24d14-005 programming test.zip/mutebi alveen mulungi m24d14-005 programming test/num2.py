def multiplicationtable (number):
    for i in range(1,13): # loop from 1 to 12
        print(f"{number}x {i} = {number*i}")
number = int(input("Enter a number:"))
multiplicationtable(number)
             