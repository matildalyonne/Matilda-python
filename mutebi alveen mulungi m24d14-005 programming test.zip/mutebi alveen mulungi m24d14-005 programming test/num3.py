def largestnumber(numbers):
    if not numbers:
        return None 
    largest = numbers[0]
    for number in numbers:
        if number > largest:
            largest = number
    return largest
numbers = [236, 34, 364, 3734, 4942, 43589, 736]
print("The largest number is:", largestnumber(numbers))