def same_string(input_string, check_string):
    return input_string == check_string
print(same_string("United","United")) # Output: True
print(same_string("United","Arsenal")) # Output: False